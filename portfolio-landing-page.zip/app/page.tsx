import { HeroSection } from "@/components/landing/hero-section"
import { ServicesSection } from "@/components/landing/services-section"
import { TargetAudienceSection } from "@/components/landing/target-audience-section"
import { AboutSection } from "@/components/landing/about-section"
import { FinalCTASection } from "@/components/landing/final-cta-section"

export default function Home() {
  return (
    <main className="min-h-screen scroll-smooth bg-background">
      <HeroSection />
      <ServicesSection />
      <TargetAudienceSection />
      <AboutSection />
      <FinalCTASection />
    </main>
  )
}
