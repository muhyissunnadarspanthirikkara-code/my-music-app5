"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Sparkles, ArrowRight } from "lucide-react"

export function FinalCTASection() {
  return (
    <section className="relative py-20 lg:py-32">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-t from-primary/5 via-transparent to-transparent" />

      <div className="container relative mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mx-auto max-w-3xl text-center"
        >
          {/* Headline */}
          <h2 className="mb-6 font-[var(--font-space-grotesk)] text-3xl font-bold text-foreground md:text-4xl lg:text-5xl">
            READY TO <span className="text-primary">TRANSFORM</span> YOUR BRAND?
          </h2>

          <p className="mb-10 text-lg text-muted-foreground">
            Let&apos;s create something extraordinary together. Book your free consultation and discover how professional design can elevate your business.
          </p>

          {/* CTA Button */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <Button
              size="lg"
              className="group relative overflow-hidden bg-primary px-10 py-6 text-lg text-primary-foreground transition-all duration-300 hover:scale-[1.05] hover:shadow-[0_0_40px_rgba(56,189,248,0.5)]"
            >
              {/* Pulse animation */}
              <motion.span
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="absolute inset-0 rounded-md bg-primary/50 blur-md"
              />
              <span className="relative flex items-center gap-2">
                <Sparkles className="h-5 w-5" />
                BOOK A FREE CONSULTATION
                <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
              </span>
            </Button>
          </motion.div>

          {/* Trust indicators */}
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="mt-8 flex flex-wrap items-center justify-center gap-6 text-sm text-muted-foreground"
          >
            <span className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-primary" />
              7+ Years Experience
            </span>
            <span className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-primary" />
              100+ Happy Clients
            </span>
            <span className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-primary" />
              Premium Quality
            </span>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}
