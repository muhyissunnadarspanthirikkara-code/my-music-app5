"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Palette, Layers, Video, Share2 } from "lucide-react"

const services = [
  {
    icon: Palette,
    title: "UI/UX Design",
    description: "What I would do to find clients if I were starting fresh in the market today.",
  },
  {
    icon: Layers,
    title: "Brand Identity",
    description: "The work methods I believe have made all the difference in achieving great results with @checkdsign.",
  },
  {
    icon: Video,
    title: "Motion Graphics",
    description: "A step-by-step guide from zero to becoming a reference and being sought after by clients.",
  },
  {
    icon: Share2,
    title: "Social Media Design",
    description: "How to develop the 3 freedoms that a designer career offers in your life.",
  },
]

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.15,
    },
  },
}

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.6,
    },
  },
}

export function ServicesSection() {
  return (
    <section className="relative py-20 lg:py-32">
      <div className="container mx-auto px-4">
        {/* Section Title */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-16 text-center"
        >
          <h2 className="font-[var(--font-space-grotesk)] text-3xl font-bold text-foreground md:text-4xl lg:text-5xl">
            WHAT YOU WILL <span className="text-primary">LEARN</span>
          </h2>
          <div className="mx-auto mt-4 h-1 w-24 bg-primary" />
        </motion.div>

        {/* Services Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="mb-12 grid gap-6 md:grid-cols-2 lg:grid-cols-4"
        >
          {services.map((service, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              whileHover={{ y: -8, scale: 1.02 }}
              className="group relative rounded-2xl border border-border bg-card/50 p-6 transition-all duration-300 hover:border-primary/50 hover:shadow-[0_0_30px_rgba(56,189,248,0.15)]"
            >
              {/* Icon */}
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-xl bg-primary/10 transition-colors group-hover:bg-primary/20">
                <service.icon className="h-8 w-8 text-primary" />
              </div>

              {/* Content */}
              <h3 className="mb-3 font-[var(--font-space-grotesk)] text-lg font-bold text-foreground">
                {service.title}
              </h3>
              <p className="text-sm leading-relaxed text-muted-foreground">
                {service.description}
              </p>

              {/* Hover glow effect */}
              <div className="absolute inset-0 -z-10 rounded-2xl bg-gradient-to-br from-primary/5 to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
            </motion.div>
          ))}
        </motion.div>

        {/* CTA Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="text-center"
        >
          <Button
            size="lg"
            className="bg-primary text-primary-foreground transition-all duration-300 hover:scale-[1.02] hover:shadow-[0_0_30px_rgba(56,189,248,0.4)]"
          >
            VIEW PORTFOLIO
          </Button>
        </motion.div>
      </div>
    </section>
  )
}
