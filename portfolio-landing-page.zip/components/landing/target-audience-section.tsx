"use client"

import { motion } from "framer-motion"

const audiences = [
  {
    number: "01",
    title: "Startups & New Businesses",
    description: "You&apos;re a beginner and want to start on the right foot in the profession.",
  },
  {
    number: "02",
    title: "Established Companies",
    description: "You already work as a designer but want to improve your processes and leverage your results.",
  },
  {
    number: "03",
    title: "Creators & Agencies",
    description: "You want to stand out in the market and increase your value, being recognized as a professional designer.",
  },
]

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2,
    },
  },
}

const itemVariants = {
  hidden: { opacity: 0, x: -30 },
  visible: {
    opacity: 1,
    x: 0,
    transition: {
      duration: 0.6,
    },
  },
}

export function TargetAudienceSection() {
  return (
    <section className="relative py-20 lg:py-32">
      {/* Background accent */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-secondary/20 to-transparent" />

      <div className="container relative mx-auto px-4">
        {/* Section Title */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-16 text-center"
        >
          <h2 className="font-[var(--font-space-grotesk)] text-3xl font-bold text-foreground md:text-4xl lg:text-5xl">
            THIS IS <span className="text-primary">PERFECT FOR</span>
          </h2>
          <div className="mx-auto mt-4 h-1 w-24 bg-primary" />
        </motion.div>

        {/* Audience Cards */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid gap-6 md:grid-cols-3"
        >
          {audiences.map((audience, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              whileHover={{ scale: 1.02 }}
              className="group relative overflow-hidden rounded-2xl border border-border bg-card/30 p-8 transition-all duration-300 hover:border-primary/50"
            >
              {/* Large Number */}
              <div className="mb-6">
                <span className="font-[var(--font-space-grotesk)] text-6xl font-bold text-primary drop-shadow-[0_0_20px_rgba(56,189,248,0.5)]">
                  {audience.number}
                </span>
              </div>

              {/* Decorative line */}
              <div className="mb-6 h-px w-full bg-gradient-to-r from-primary via-primary/50 to-transparent" />

              {/* Content */}
              <h3 className="mb-3 font-[var(--font-space-grotesk)] text-xl font-bold text-foreground">
                {audience.title}
              </h3>
              <p className="leading-relaxed text-muted-foreground">
                {audience.description}
              </p>

              {/* Corner accent */}
              <div className="absolute -right-4 -top-4 h-16 w-16 rounded-full bg-primary/10 blur-2xl transition-all group-hover:bg-primary/20" />
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
