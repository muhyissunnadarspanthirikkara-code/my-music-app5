"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"

export function AboutSection() {
  return (
    <section className="relative py-20 lg:py-32">
      <div className="container mx-auto px-4">
        <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
          {/* Left Column - Text */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="space-y-6"
          >
            {/* Section Title */}
            <div>
              <h2 className="font-[var(--font-space-grotesk)] text-3xl font-bold text-foreground md:text-4xl lg:text-5xl">
                MEET <span className="text-primary">MUHAMMED</span>
              </h2>
              <div className="mt-4 h-1 w-24 bg-primary" />
            </div>

            {/* Bio */}
            <div className="space-y-4 text-muted-foreground">
              <p className="leading-relaxed">
                Muhammed probably had a start very similar to yours.
              </p>
              <p className="leading-relaxed">
                Self-taught in design, he chased after his first clients and has been carving out his space one project at a time.
              </p>
              <p className="leading-relaxed">
                He founded the agency <span className="font-semibold text-primary">checkdsign</span> and his courses{" "}
                <span className="font-semibold text-foreground">Designer Income</span> and{" "}
                <span className="font-semibold text-foreground">Social Media Income</span> have already reached thousands of students and generated a{" "}
                <span className="font-semibold text-foreground">massive amount of content</span>.
              </p>
              <p className="leading-relaxed">
                Now, he&apos;s going to open up his playbook and show you everything you need to become a standout professional in the design market.
              </p>
            </div>

            {/* CTA */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <Button
                size="lg"
                className="bg-primary text-primary-foreground transition-all duration-300 hover:scale-[1.02] hover:shadow-[0_0_30px_rgba(56,189,248,0.4)]"
              >
                BOOK A FREE CONSULTATION
              </Button>
            </motion.div>
          </motion.div>

          {/* Right Column - Image */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative flex justify-center"
          >
            {/* Background glow */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="h-72 w-72 rounded-full bg-primary/15 blur-3xl" />
            </div>

            {/* Image container */}
            <div className="relative z-10">
              <div className="relative h-[400px] w-[350px] overflow-hidden rounded-2xl bg-gradient-to-br from-secondary to-card lg:h-[500px] lg:w-[400px]">
                {/* Gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-background/60 via-transparent to-transparent" />
                
                {/* Placeholder for photo */}
                <div className="absolute inset-0 flex items-end justify-center">
                  <div className="h-[95%] w-[85%] rounded-t-full bg-gradient-to-t from-muted/60 to-secondary/40" />
                </div>
              </div>

              {/* Decorative elements */}
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                className="absolute -right-6 -top-6 h-12 w-12 rounded-full border-2 border-dashed border-primary/30"
              />
              <motion.div
                animate={{ rotate: -360 }}
                transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
                className="absolute -bottom-4 -left-4 h-8 w-8 rounded-full border-2 border-dashed border-primary/40"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
