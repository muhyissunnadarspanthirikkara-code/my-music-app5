"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Calendar, Sparkles } from "lucide-react"

const floatingIcons = [
  { icon: "Ps", delay: 0, x: 20, y: -30 },
  { icon: "Ai", delay: 0.2, x: -40, y: 20 },
  { icon: "Ae", delay: 0.4, x: 30, y: 60 },
  { icon: "Xd", delay: 0.6, x: -20, y: -50 },
]

export function HeroSection() {
  return (
    <section className="relative min-h-screen overflow-hidden py-12 lg:py-20">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-background via-background to-secondary/30" />
      
      <div className="container relative mx-auto px-4">
        <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-8">
          {/* Left Column - Content */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            {/* Logo/Brand */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2 }}
              className="inline-block"
            >
              <h2 className="font-[var(--font-space-grotesk)] text-2xl font-bold tracking-wider text-primary">
                PROFESSIONAL DESIGNER
              </h2>
              <div className="mt-1 h-1 w-16 bg-primary" />
            </motion.div>

            {/* Main Headline */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.7 }}
            >
              <p className="mb-4 text-muted-foreground">
                After 7+ years in the market, X+ clients, and countless trials and successes...
              </p>
              <h1 className="text-balance font-[var(--font-space-grotesk)] text-3xl font-bold leading-tight text-foreground md:text-4xl lg:text-5xl">
                <span className="text-primary">TRANSFORMING IDEAS</span> INTO STUNNING DESIGNS THAT ELEVATE YOUR BRAND
              </h1>
            </motion.div>

            {/* Subtext */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5, duration: 0.7 }}
              className="text-lg text-muted-foreground"
            >
              Save time, money, and years of frustration by working with a professional who understands your vision.
            </motion.p>

            {/* Form */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6, duration: 0.7 }}
              className="space-y-4"
            >
              <p className="text-sm font-medium text-foreground">
                Get in touch for free below:
              </p>
              <div className="flex flex-col gap-3 sm:max-w-md">
                <Input
                  type="text"
                  placeholder="Your first name"
                  className="border-border bg-secondary/50 text-foreground placeholder:text-muted-foreground focus:border-primary focus:ring-primary"
                />
                <Input
                  type="email"
                  placeholder="Your best email"
                  className="border-border bg-secondary/50 text-foreground placeholder:text-muted-foreground focus:border-primary focus:ring-primary"
                />
                <Button
                  size="lg"
                  className="group relative overflow-hidden bg-primary text-primary-foreground transition-all duration-300 hover:scale-[1.02] hover:shadow-[0_0_30px_rgba(56,189,248,0.4)]"
                >
                  <Sparkles className="mr-2 h-4 w-4" />
                  GET IN TOUCH
                </Button>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Calendar className="h-4 w-4 text-primary" />
                <span>Available for new projects</span>
              </div>
            </motion.div>
          </motion.div>

          {/* Right Column - Image with floating icons */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="relative flex items-center justify-center"
          >
            {/* Background glow */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="h-80 w-80 rounded-full bg-primary/20 blur-3xl" />
            </div>

            {/* Main image placeholder */}
            <div className="relative z-10">
              <div className="relative h-[400px] w-[350px] overflow-hidden rounded-2xl bg-gradient-to-br from-secondary to-card lg:h-[500px] lg:w-[400px]">
                <div className="absolute inset-0 flex items-end justify-center bg-gradient-to-t from-background/80 to-transparent">
                  <div className="h-full w-full bg-gradient-to-br from-primary/10 to-accent/10" />
                </div>
                {/* Placeholder silhouette */}
                <div className="absolute inset-0 flex items-end justify-center">
                  <div className="h-[90%] w-[80%] rounded-t-full bg-gradient-to-t from-secondary/80 to-muted/50" />
                </div>
              </div>

              {/* Floating icons */}
              {floatingIcons.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.8 + item.delay, duration: 0.5 }}
                  className="absolute"
                  style={{
                    top: `${30 + index * 15}%`,
                    right: index % 2 === 0 ? `-${20 + index * 5}px` : "auto",
                    left: index % 2 !== 0 ? `-${20 + index * 5}px` : "auto",
                  }}
                >
                  <motion.div
                    animate={{
                      y: [0, item.y / 3, 0],
                      x: [0, item.x / 3, 0],
                    }}
                    transition={{
                      duration: 4 + index,
                      repeat: Infinity,
                      ease: "easeInOut",
                    }}
                    className="flex h-14 w-14 items-center justify-center rounded-xl bg-card shadow-lg shadow-primary/20 lg:h-16 lg:w-16"
                  >
                    <span className="font-[var(--font-space-grotesk)] text-lg font-bold text-primary">
                      {item.icon}
                    </span>
                  </motion.div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
